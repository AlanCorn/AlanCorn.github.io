// import { ref, reactive, toRefs, getCurrentInstance } from 'vue-demi'

// const useBlog = () => {
//   const currentPage = ref(1)
//   return {}
// }

// export { useBlog }
